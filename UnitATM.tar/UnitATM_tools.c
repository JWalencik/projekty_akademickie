#include "UnitATM_tools.h"

int char_to_int(const char* buf, unsigned int* var)
{
        char* pEnd;
        unsigned long value = strtoul(buf, &pEnd, 10);

        if(value > UINT_MAX)
        {
                fprintf(stderr, "OUT OF RANGE, Program accepts only non-negative numbers\n");
                return 1;
        }

        if (*pEnd != '\0' && !isspace(*pEnd))
        {
                fprintf(stderr, "INVALID FORMAT\n");
                return 1;
        }

        *var = (unsigned int)value;

        return 0;
}

int count_zasoby(char* buf, unsigned int* zasoby)
{
        char* token = strtok(buf, ":");
        int i = 0;

        while (token != NULL && i < 3)
        {
                if(char_to_int(token, &zasoby[i])) return 1;
                token = strtok(NULL, ":");
                ++i;
        }

        if(i<3)
        {
                fprintf(stderr, "-m has not enough numbers, must be three\n");
                return 1;
        }

        return 0;
}

int correct_line(const char* buf)
{
        int pos_number = 0;
        int checkpoint = 0;
        for(int i=0; buf[i] != '\0'; ++i)
        {
                if(!isdigit(buf[i]) && !isspace(buf[i]))
                {
                        fprintf(stderr, "INVALID FORMAT, found unwanted character\n");
                        return 0;
                }

                if(isdigit(buf[i]))
                {
                        if(checkpoint)
                        {
                                fprintf(stderr, "INVALID FORMAT, found two numbers in one line\n");
                                return 0;
                        }
                        else
                        {
                                pos_number = 1;
                        }
                }

                if(isspace(buf[i]) && pos_number)
                {
                        checkpoint = 1;
                }
        }

        if(pos_number) return 1;

        return 0;
}

int zetony(int kwota)
{
        int a, b;
        int suma = 0;

        for(int i=0; i<3; ++i)
        {
                a = kwota / Nominaly[i];
                b = F_MAX(0, (zasoby[i] - a));
                count_zetony[i] = zasoby[i] - b;
                zasoby[i] = b;
                kwota -= (Nominaly[i] * count_zetony[i]);
                suma += (Nominaly[i] * count_zetony[i]);
        }

        if(kwota != 0)
        {
                fprintf(stdout, "UNPAID CHANGE: %d\n", kwota);
        }

        return 0;
}

int F_MAX(int X, int Y)
{
        return ((X > Y) ? X : Y);
}

void rand_wydanie_zeton(unsigned int s, unsigned int t, unsigned int d)
{
        srandom(s);
        int suma = count_zetony[0]+count_zetony[1]+count_zetony[2];

        time_t ns_nap = d*C_SEC;
        time_t s_nap = ns_nap / SEC;
        ns_nap %= SEC;

        for(int i=suma ; i>0 ; --i)
        {
                int index = random()%3;
                while(count_zetony[index] == 0)
                {
                        if(!index)
                                index = 2;
                        else
                                --index;
                }
                dprintf(t, "%d\n", Nominaly[index]);
                --count_zetony[index];
        }
        dprintf(t, "\n");
        if(nanosleep(&(struct timespec){s_nap, ns_nap}, NULL) == -1)
        {
                fprintf(stderr, "NANOSLEEP FAILIER\n");
        }
}
