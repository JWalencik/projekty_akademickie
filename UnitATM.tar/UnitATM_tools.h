#ifndef _UNIT_ATM_TOOLS_H_
#define _UNIT_ATM_TOOLS_H_

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <string.h>
#include <fcntl.h>
#include <ctype.h>
#include <time.h>

#define C_SEC 10000000
#define SEC 1000000000

extern unsigned int Nominaly[3];
extern unsigned int zasoby[3];
extern unsigned int count_zetony[3];

int char_to_int(const char* buf, unsigned int* value);
//zamienia �a�cuch znakowy na unsigned int | buf to �a�cuch | value to wska�nik na zmienn� w ktora wsadzamy int | pos to wskaznik na bramke zmiennych obowiazkowych
//jesli zmiana przebiegla poprawnia bramka jest zmieniania na wartosc nie-zerowa
//jesli funkcja wykonala sie bez bledow to zwraca 0 | z bledami 1
//
int count_zasoby(char* buf, unsigned int* zasoby);
//bierze lanuch i rozdziela na poszczegolne liczby | buf to lancuch | zasoby to wskaznik tablicy | pos jak powyzej
//jesli funkcja wykonala sie bez bledow to zwraca 0 | z bledami 1

int correct_line(const char* buf);
//sprawdza czy lancuch zakonczony zerem spelnia wymagania | buf to nasz lancuhc
//jak znajdzie lancuch z znakami nie-cyfrowymi i nie bedacymi znakami bialymi lub wiersz z dwoma liczbami wyrzuci blad i zwroci 0
//jak znajdzie lancuh pusty lub wypelniony znakami bialymi to zwroci 0, bez bledu
//poprawne wykonanie zwraca 1

int zetony(int kwota);
//oblicza wydawane zetony i czy zostanie jakas reszta w przypadku braku zasobow

int F_MAX(int X, int Y);

void rand_wydanie_zeton(unsigned int s, unsigned int t, unsigned int d);
//wypisuje w losowej kolejosci odpowiednia liczbe zetonow kazdego nominalu, z przerwa d centysekund

#endif
