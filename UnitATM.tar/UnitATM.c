#include "UnitATM_tools.h"

unsigned int Nominaly[3] = {5, 2, 1};
unsigned int zasoby[3] = {};
unsigned int count_zetony[3] = {};

int main(int argc, char* argv[])
{
        int opt;
        int pos_m = 0;
        int pos_t = 0;
        unsigned int t;
        unsigned int u = 0;
        unsigned int s = getpid();
        unsigned int d = 1;

        while ((opt = getopt(argc, argv, "m:t:u:s:d:")) != -1)
        {
                switch(opt)
                {
                        case 'm':
                                if(count_zasoby(optarg, zasoby)) return 1;
                                pos_m = 1;
                                break;
                        case 't':
                                if(char_to_int(optarg, &t)) return 1;
                                if( t == 0 )
                                {
                                        fprintf(stderr, "Inncorect t value");
                                        return 1;
                                }
                                pos_t = 1;
                                break;
                        case 'u':
                                if(char_to_int(optarg, &u)) return 1;
                                break;
                        case 's':
                                if(char_to_int(optarg, &s)) return 1;
                                break;
                        case 'd':
                                if(char_to_int(optarg, &d)) return 1;
                                break;
                        default:
                                fprintf(stderr, "Correct usage: %s -m<string> -t<uint> [optional: -u<uint>, -s<int>, -d<uint>]\n", argv[0]);
                                return 1;
                }
        }

        if(!pos_m || !pos_t)
        {
                fprintf(stderr, "-m and -t are required");
                return 1;
        }

        size_t buf_size = 1024;

        char* buffer = (char*)malloc(buf_size * sizeof(char));
        if(buffer == NULL)
        {
                fprintf(stderr, "MALLOC FILE\n");
                return 1;
        }

        unsigned int skala = 1;
        unsigned int kwota;

        for(int i=0; i<u; ++i)
        {
                skala *= 10;
        }

        for(int i=0; i<3; ++i)
        {
                Nominaly[i] *= skala;
        }

        while (getline(&buffer, &buf_size, stdin) != -1)
        {
                if(!correct_line(buffer))
                {
                        continue;
                }

                if(char_to_int(buffer, &kwota)) return 1;
                zetony(kwota);
                rand_wydanie_zeton(s, t, d);
        }

        free(buffer);
        return 0;
}
